from django import forms

class LoginForm(forms.Form):
    username = forms.Charfield(label='Username',max_length=100)
    password = forms.Charfield(label='Password',widget=forms.PasswordInput)
