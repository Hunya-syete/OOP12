from django.urls import path
from myapp.views import user_login, success

urlspatters= [
    path('login/',user_login, name='login'),
    path('succeess/', success, name='success'),
]