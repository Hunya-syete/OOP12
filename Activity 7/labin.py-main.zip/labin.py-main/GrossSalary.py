def Calc_GrossSalary(Hours: int):
    return 500 * Hours