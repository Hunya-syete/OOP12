def Calc_NetSalary(GrossSalary: int, SalaryDeduction: int):
    return GrossSalary - SalaryDeduction